Description:
  Basic RPG item icons created by yinakoSGA.

Licensing:
  Creative Commons Attribution (CC BY) 3.0

Links:
  Original OGA submission: https://opengameart.org/node/16759
